EnemyMovement = {
	
	speed = 1,

	OnStart = function(self)
		self.transform = self.actor:GetComponent("Transform")
		self.xspd = self.speed
		self.yspd = self.speed
	end,

	OnUpdate = function(self)

		if self.transform.x + 100 >= Window.GetWidth() then
			self.xspd = -math.abs(self.xspd)
			RAudio.Play(1, "hit_wall", false)
		end

		if self.transform.x <= 0 then
			self.xspd = math.abs(self.xspd)
			RAudio.Play(1, "hit_wall", false)
		end

		if self.transform.y + 100 >= Window.GetHeight() then
			self.yspd = -math.abs(self.yspd)
			RAudio.Play(1, "hit_wall", false)
		end

		if self.transform.y <= 0 then
			self.yspd = math.abs(self.yspd)
			RAudio.Play(1, "hit_wall", false)
		end
		
		self.transform.x = self.transform.x + self.xspd
		self.transform.y = self.transform.y + self.yspd

	end
}

