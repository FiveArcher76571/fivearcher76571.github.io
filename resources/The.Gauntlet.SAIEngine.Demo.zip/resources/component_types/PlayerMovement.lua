PlayerMovement = {

    speed = 0.1,

    OnStart = function(self)
        self.transform = self.actor:GetComponent("Transform")
    end,

    OnUpdate = function(self)

        if Input.GetKey("w") then self.transform.y = self.transform.y - self.speed end
        if Input.GetKey("s") then self.transform.y = self.transform.y + self.speed end
        if Input.GetKey("a") then self.transform.x = self.transform.x - self.speed end
        if Input.GetKey("d") then self.transform.x = self.transform.x + self.speed end

        -- Restrict to boundaries
        if self.transform.x < 0 then self.transform.x = 0 end
        if self.transform.x + 100 > Window.GetWidth() then self.transform.x = Window.GetWidth() - 100 end
        if self.transform.y < 0 then self.transform.y = 0 end
        if self.transform.y + 100 > Window.GetHeight() then self.transform.y = Window.GetHeight() - 100 end

        if Input.GetKey("escape") then Application.Quit() end

    end
}

