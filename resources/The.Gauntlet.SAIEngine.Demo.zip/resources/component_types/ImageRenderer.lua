ImageRenderer = {

    image = "",

    OnStart = function(self)

        self.transform = self.actor:GetComponent("Transform")

    end,

    OnUpdate = function(self)

        Image.DrawUIEx(self.image, self.transform.x, self.transform.y, 255, 255, 255, 255, 0)

    end

}