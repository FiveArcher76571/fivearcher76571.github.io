EnemySpawner = {

    num = 0,
    speed = 1,

    OnStart = function(self)

        math.randomseed(os.time())

        for i = 1, self.num do

            -- Make a new enemy
            new_enemy = Actor.Instantiate("enemy")

            -- Set its position to random between window dimensions
            new_enemy:GetComponent("Transform").x = math.random(10, Window.GetWidth() - 10)
            new_enemy:GetComponent("Transform").y = math.random(10, 200)

            -- Set speed
            new_enemy:GetComponent("EnemyMovement").speed = self.speed

        end

    end

}