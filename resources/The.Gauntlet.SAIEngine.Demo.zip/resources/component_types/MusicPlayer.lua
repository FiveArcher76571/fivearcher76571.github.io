MusicPlayer = {

    track = "",
    loop = true,

    OnStart = function(self)
        RAudio.Play(0, self.track, self.loop)
    end

}