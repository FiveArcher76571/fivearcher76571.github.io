TitleInput = {

    OnUpdate = function(self)

        if Input.GetKeyDown("space") then Scene.Switch("gameplay") end
        if Input.GetKeyDown("escape") then Application.Quit() end

    end

}