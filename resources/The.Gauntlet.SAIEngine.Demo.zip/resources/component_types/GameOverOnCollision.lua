GameOverOnCollision = {

    OnStart = function(self)

        self.player_tf = Actor.Find("player"):GetComponent("Transform")
        self.tf = self.actor:GetComponent("Transform")

    end,

    OnUpdate = function(self)

        if self.tf.x < self.player_tf.x + 100 and self.tf.x + 75 > self.player_tf.x and self.tf.y < self.player_tf.y + 100 and self.tf.y + 75 > self.player_tf.y then

            -- Game Over!!!
            Scene.Switch("lose")

        end

    end

}