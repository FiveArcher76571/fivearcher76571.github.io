WinTracker = {

    limit = 10,

    OnStart = function(self)

        self.timer = 0

    end,

    OnUpdate = function(self)

        if self.timer >= self.limit then Scene.Switch("win") end

        if Application.GetFrame() % 60 == 0 then self.timer = self.timer + 1 end

        Text.Draw(self.timer, 10, 10, "NotoSans-Regular", 50, 255, 255, 255, 255)

    end

}